<?php
    header("Content-Type: text/html;charset=utf-8");
    include '../com/DBHelper.php';
    //获取表单传递的参数
    $login_Username=$_POST["login_Username"];
    $login_Password=$_POST["login_Password"];
    $DB=New DBHelper();
    $Resoult=$DB->QuerySQL("select * from sys_user where username='{$login_Username}' and password='{$login_Password}'");
    echo $Resoult;
?>