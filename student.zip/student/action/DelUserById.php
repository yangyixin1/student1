<?php
    header("Content-Type: text/html;charset=utf-8");
    include '../com/DBHelper.php';
    $Id=$_POST["Id"];
    $DB=New DBHelper();
    $Resoult=$DB->ExecSQL("delete from sys_user where Id={$Id}");
    echo $Resoult;
?>