<?php
    header("Content-Type: text/html;charset=utf-8");
    include '../com/DBHelper.php';
    $DB=New DBHelper();
    $Resoult=$DB->GetTotal("select * from sys_user where user_type='普通用户'");
    echo $Resoult;
?>