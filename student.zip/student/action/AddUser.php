<?php
    header("Content-Type: text/html;charset=utf-8");
    include '../com/DBHelper.php';
    //获取表单传递的参数
    $username=$_POST["username"];
    $sex=$_POST["sex"];
    $address=$_POST["address"];
    $password=$_POST["password"];
    $Email=$_POST["Email"];
    $phone=$_POST["phone"];
    $DB=New DBHelper();
    $Resoult=$DB->ExecSQL("insert into sys_user(username,password,email,sex,address,phone_number,create_time,user_type) values('{$username}','{$password}','{$Email}','{$sex}','{$address}','{$phone}',now(),'普通用户');");
    echo $Resoult;
?>