<?php
    header("Content-Type: text/html;charset=utf-8");
    include '../com/DBHelper.php';
    //获取表单传递的参数
    $Id=$_POST["Id"];
    $username=$_POST["username"];
    $sex=$_POST["sex"];
    $address=$_POST["address"];
    $password=$_POST["password"];
    $email=$_POST["email"];
    $phone=$_POST["phone"];
    $DB=New DBHelper();
    $Resoult=$DB->ExecSQL("update sys_user set username='{$username}',password='{$password}',email='{$email}',sex='{$sex}',address='{$address}',phone_number='{$phone}' where Id={$Id}");
    echo $Resoult;
?>